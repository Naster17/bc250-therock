#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Audit square BF16 projection layouts on the unchanged qualified stack."""
from qualify_training_n33_on_host import main


if __name__ == "__main__":
    main(
        batch_id="training-n34",
        shape=(1024, 2048, 2048),
        baseline_label="training-n33-qualification-r4",
        default_phase="gemm",
    )
